<?php
/*
* Author: Ubakarasamy
* Company: Ivisual
* URI: ubakarasamy.com
*/

include('db_config.php');


//updating current wallet total money
/*
$sql = "UPDATE wallet_total SET wallet_money = wallet_money + 200 WHERE customer_id = 1";

*/



/*
* get discount datas from successfull checkout
* 
* insert to discounts_byproduct
*
*/


//get data from discounts_byproduct table 

$sql = "SELECT * FROM discounts_byproduct";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	?>	
<table style="width:100%">
  <caption>Your discount Amount</caption>
  <tr>
    <th>Product</th>
    <th>Purchased Date</th>
    <th>Discount amount</th>
    <th>Days To Approval</th>
    <th>Approval Status</th>
  </tr>
<?php while($row = $result->fetch_assoc()) { ?>
  <tr>
    <td><?php echo $row["product_name"] ?></td>
    <td><?php echo $row["date"] ?></td>
    <td><?php echo $row["discount_amount"] ?></td>
    <td><?php echo $row["ndays_toapprove"] ?></td>
    <td><?php 
	if ($row["status"] == 1){
		echo "Approved";
	}elseif($row["status"] == 0){
		echo "Not Approved";    
	}
	 ?>
	
	</td>
  </tr>
<?php } ?>
</table>
<?php } ?>
	

<?php
/*
if product canceled

remove discount or status = removed

?>