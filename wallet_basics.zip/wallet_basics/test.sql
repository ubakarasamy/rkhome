-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2017 at 06:32 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `discounts_byproduct`
--

CREATE TABLE `discounts_byproduct` (
  `id` int(255) NOT NULL,
  `date` datetime(6) NOT NULL,
  `discount_percentage` int(11) NOT NULL,
  `discount_amount` int(255) NOT NULL,
  `product_id` int(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_categoryid` int(255) NOT NULL,
  `customer_id` int(255) NOT NULL,
  `ndays_toapprove` int(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discounts_byproduct`
--

INSERT INTO `discounts_byproduct` (`id`, `date`, `discount_percentage`, `discount_amount`, `product_id`, `product_name`, `product_categoryid`, `customer_id`, `ndays_toapprove`, `status`) VALUES
(1, '2017-11-05 10:00:00.000000', 20, 200, 1, 'vivo y51l', 1, 1, 90, 0),
(2, '2017-11-05 11:00:00.000000', 25, 250, 2, 'oppo a57', 2, 2, 90, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wallet_total`
--

CREATE TABLE `wallet_total` (
  `id` int(11) NOT NULL,
  `customer_id` int(255) NOT NULL,
  `wallet_money` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wallet_total`
--

INSERT INTO `wallet_total` (`id`, `customer_id`, `wallet_money`) VALUES
(1, 1, 700);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `discounts_byproduct`
--
ALTER TABLE `discounts_byproduct`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wallet_total`
--
ALTER TABLE `wallet_total`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `discounts_byproduct`
--
ALTER TABLE `discounts_byproduct`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wallet_total`
--
ALTER TABLE `wallet_total`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
